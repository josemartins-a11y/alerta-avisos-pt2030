# Alerta de novos avisos — Portugal 2030

Verifica https://portugal2030.pt/avisos/ três vezes por dia (08h, 13h, 18h,
hora de Lisboa) e envia um email quando aparecem avisos novos.

Solução gratuita, baseada em **GitHub Actions** (não precisas de servidor
nem de pagar nada). Não precisas de escrever nem editar código — só de
seguir os passos abaixo.

## Passo 1 — Criar o repositório

1. Cria uma conta em https://github.com (gratuita), se ainda não tiveres.
2. Cria um novo repositório **privado** (ex: `alerta-avisos-pt2030`).
3. Faz upload destes 3 ficheiros, mantendo esta estrutura de pastas:

```
alerta-avisos-pt2030/
├── check_avisos.py
└── .github/
    └── workflows/
        └── check_avisos.yml
```

(No GitHub, usa "Add file → Upload files" e arrasta os ficheiros; garante
que a pasta `.github/workflows/` fica exatamente com este nome.)

## Passo 2 — Criar uma password de aplicação para o email

Se usares Gmail para enviar os alertas:

1. Ativa a verificação em 2 passos na tua conta Google (obrigatório).
2. Vai a https://myaccount.google.com/apppasswords e gera uma "app
   password" para "Mail".
3. Guarda essa password — vais precisar dela no passo seguinte.

(Podes usar outro fornecedor de email/SMTP se preferires — só precisas do
servidor SMTP, porta, utilizador e password.)

## Passo 3 — Configurar os "Secrets" no GitHub

No repositório: **Settings → Secrets and variables → Actions → New
repository secret**. Cria estes 5 secrets:

| Nome | Valor (exemplo com Gmail) |
|---|---|
| `SMTP_HOST` | `smtp.gmail.com` |
| `SMTP_PORT` | `465` |
| `SMTP_USER` | o teu email (ex: `jose@gmail.com`) |
| `SMTP_PASS` | a app password gerada no Passo 2 |
| `EMAIL_TO` | o email que deve receber os alertas (pode ser o mesmo) |

## Passo 4 — Criar a "baseline" (primeira execução)

Vai ao separador **Actions** do repositório → escolhe o workflow
"Verificar avisos Portugal 2030" → **Run workflow**.

Esta primeira execução **não envia email** — apenas grava a lista atual de
avisos abertos como ponto de partida. A partir da segunda verificação em
que houver avisos novos, recebes o email.

## Passo 5 — Confirmar que fica a correr sozinho

A partir daqui, o workflow corre automaticamente todas as horas, mas só
faz a verificação real às 08h, 13h e 18h (hora de Lisboa) — as outras
execuções terminam de imediato sem fazer nada. Não precisas de repetir o
Passo 4.

## Nota importante sobre os seletores de HTML

A página de avisos carrega o conteúdo via JavaScript, por isso o script
usa um browser automatizado (Playwright) e apanha, de forma genérica,
todos os links que apontam para `/avisos/`. Isto deve funcionar para
detetar avisos novos, mas os **títulos podem não vir perfeitamente
limpos** dependendo da estrutura real da página.

Se quiseres afinar isto (ex: separar título, prazo e programa em campos
distintos no email), corre o script localmente com a variável de ambiente
`DEBUG_DUMP_HTML=1` — isso grava `debug_page.html` com o HTML real
carregado, que podes depois usar (ou pedir-me para usar) para ajustar os
seletores no `check_avisos.py`.

## Manutenção

- O GitHub desativa workflows agendados ao fim de 60 dias sem atividade
  no repositório — mas como este workflow faz commit do estado a cada
  execução, isso conta como atividade e mantém-se sempre ativo sozinho.
- Se um dia mudares o URL a monitorizar ou quiseres adicionar outras
  páginas (ex: COMPETE 2030, Norte 2030), a lógica é a mesma — basta
  duplicar a função `fetch_avisos` para o novo URL.
